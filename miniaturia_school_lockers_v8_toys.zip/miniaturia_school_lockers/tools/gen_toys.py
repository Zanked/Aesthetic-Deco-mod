"""Генератор игрушек (воксельные модели из кубоидов, одна общая текстура-палитра).

    python3 tools/gen_toys.py

Создаёт: textures/block/toys_palette.png, models/block|item/toy_*.json, blockstates, loot tables,
записи в lang/en_us.json и ru_ru.json и java/.../ToyData.java.
Перед лицом игрушки — север (-Z); поворот делает блокстейт.
Партия 1: плюшевые игрушки.
"""
import json
import os

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/schoollockers"
D = f"{RES}/data/schoollockers"
JAVA = f"{ROOT}/src/main/java/ru/miniaturia/schoollockers"

CELL = 4  # px на цвет в палитре (64x64 = 16x16 цветов)

# ---------------------------------------------------------------- палитра
PALETTE = {
    "black": "#1c1a20", "white": "#f3f1ed", "dark": "#3a2c25", "hl": "#ffffff",
    # мишка / собачка
    "brown": "#8a5530", "brown_lt": "#a56a3a", "tan": "#d9a873", "tan_lt": "#ecc9a0",
    "dog": "#dcb386", "dog_lt": "#ecd0a8", "dog_ear": "#8a5a3a",
    "red": "#d1302f", "red_dk": "#9c1f22",
    # зайчик
    "bunny": "#f3e6ea", "pink": "#f08aa3", "pink_dk": "#d55f80", "pink_lt": "#ffd0dc",
    # котик
    "gray": "#8e919a", "gray_dk": "#656872", "gray_lt": "#c9ccd2",
    # лисичка
    "orange": "#e0732a", "orange_dk": "#bd581b", "orange_lt": "#f08b3f",
    # динозавр
    "green": "#4cae3b", "green_dk": "#37902a", "green_lt": "#8fdc6a", "cream": "#f0e6c6",
    # коровка
    "cow": "#3b2622", "cow_pink": "#f2a6b5", "cow_pink_dk": "#d98798",
}


def hex2rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def cell_uv(col):
    i = list(PALETTE).index(col)
    cx, cy = i % 16, i // 16
    return [cx + 0.3, cy + 0.3, cx + 0.7, cy + 0.7]


def write_palette():
    im = Image.new("RGBA", (16 * CELL, 16 * CELL), (0, 0, 0, 0))
    for i, (_, h) in enumerate(PALETTE.items()):
        cx, cy = i % 16, i // 16
        im.paste(Image.new("RGBA", (CELL, CELL), hex2rgb(h) + (255,)), (cx * CELL, cy * CELL))
    im.save(f"{A}/textures/block/toys_palette.png")


# ---------------------------------------------------------------- DSL
class Toy:
    """Игрушка рисуется в «воксельных» единицах (cx, cz — центр, лицо на -Z) и масштабируется в блок.
    scale=0.5 → 1 воксель = 1/32 блока (игрушка ~ 20 вокселей = 10/16 блока)."""

    def __init__(self, tid, en, ru, scale=0.5, cx=10.0, cz=10.0, sx=1.0, sy=1.0, sz=1.0):
        self.id, self.en, self.ru = tid, en, ru
        self.scale, self.cx, self.cz = scale, cx, cz
        self.sx, self.sy, self.sz = sx, sy, sz  # растяжение по осям (приземистые плюшевые пропорции)
        self.els = []

    def box(self, x1, y1, z1, x2, y2, z2, col):
        assert col in PALETTE, col
        assert x2 > x1 and y2 > y1 and z2 > z1, (self.id, x1, y1, z1, x2, y2, z2)
        self.els.append(((x1, y1, z1), (x2, y2, z2), col))
        return self

    def pair(self, x1, y1, z1, x2, y2, z2, col):
        """Бокс и его зеркальное отражение по X (относительно центра игрушки)."""
        self.box(x1, y1, z1, x2, y2, z2, col)
        if abs((x1 + x2) / 2 - self.cx) > 1e-6:
            self.box(2 * self.cx - x2, y1, z1, 2 * self.cx - x1, y2, z2, col)
        return self

    def rbox(self, x1, y1, z1, x2, y2, z2, col, r=1.0):
        """Скруглённый (срезанные рёбра) бокс — 3 перекрывающихся бокса одного цвета."""
        self.box(x1, y1 + r, z1 + r, x2, y2 - r, z2 - r, col)
        self.box(x1 + r, y1 + r, z1, x2 - r, y2 - r, z2, col)
        self.box(x1 + r, y1, z1 + r, x2 - r, y2, z2 - r, col)
        return self

    def rpair(self, x1, y1, z1, x2, y2, z2, col, r=1.0):
        self.rbox(x1, y1, z1, x2, y2, z2, col, r)
        if abs((x1 + x2) / 2 - self.cx) > 1e-6:
            self.rbox(2 * self.cx - x2, y1, z1, 2 * self.cx - x1, y2, z2, col, r)
        return self

    # --- перевод в координаты блока
    def _p(self, a):
        return (8 + (a[0] - self.cx) * self.scale * self.sx, a[1] * self.scale * self.sy,
                8 + (a[2] - self.cz) * self.scale * self.sz)

    def bounds(self):
        pts = [self._p(e[0]) for e in self.els] + [self._p(e[1]) for e in self.els]
        return tuple(min(p[i] for p in pts) for i in range(3)) + tuple(max(p[i] for p in pts) for i in range(3))

    def model(self):
        els = []
        for (a, b, col) in self.els:
            uv = cell_uv(col)
            els.append({
                "from": [round(v, 3) for v in self._p(a)], "to": [round(v, 3) for v in self._p(b)],
                "faces": {d: {"uv": uv, "texture": "#p"} for d in ("north", "east", "south", "west", "up", "down")},
            })
        return {"ambientocclusion": False,
                "textures": {"p": "schoollockers:block/toys_palette",
                             "particle": "schoollockers:block/toys_palette"},
                "elements": els}


TOYS = []


def toy(tid, en, ru, **kw):
    def deco(fn):
        t = Toy(tid, en, ru, **kw)
        fn(t)
        TOYS.append(t)
        return fn
    return deco


# ---------------------------------------------------------------- плюшевые игрушки
def eyes(t, y=14.4, dx=4.0, col="black"):
    """Глаза с бликом (голова спереди z=5)."""
    cx = t.cx
    t.pair(cx - dx - 0.6, y, 4.55, cx - dx + 0.6, y + 2.0, 5.0, col)
    t.pair(cx - dx + 0.05, y + 1.3, 4.4, cx - dx + 0.55, y + 1.9, 4.55, "hl")


def muzzle(t, col, nose="black", w=2.6, y=12.0, top=15.0, out=3.8, mouth=True):
    cx = t.cx
    t.rbox(cx - w, y, out, cx + w, top, 5.5, col, 0.5)
    t.box(cx - 1.0, top - 1.4, out - 0.3, cx + 1.0, top, out, nose)
    if mouth:
        t.box(cx - 0.5, y + 0.4, out - 0.15, cx + 0.5, y + 1.4, out, "black")


def rig(t, fur, belly, head=None, arm=None, foot=None, pad=None):
    """Сидящий плюшевый зверёк: ножки, тело, пузико, лапки, большая голова. Лицо — на -Z."""
    head, arm, foot, pad = head or fur, arm or fur, foot or arm or fur, pad or belly
    t.rpair(4, 0, 4.5, 8.5, 4, 10.5, foot, 0.6)                # задние лапы, вынесены вперёд
    t.pair(5.3, 0.9, 4.2, 7.3, 2.9, 4.5, pad)                  # подушечки на подошвах
    t.rbox(5, 3, 8, 15, 12, 16, fur, 1.0)                      # тело
    t.box(7, 3.5, 7.6, 13, 9.8, 8, belly)                      # пузико
    t.rpair(3, 4, 6.5, 5.5, 10.5, 11, arm, 0.5)                # передние лапки
    t.rpair(3, 3.5, 4.5, 6, 6.5, 8, arm, 0.5)                  # ладошки на коленях
    t.rbox(3.5, 11, 5, 16.5, 20.5, 14.5, head, 1.2)            # голова
    eyes(t)


@toy("toy_bear", "Teddy Bear", "Мишка", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "brown", "tan", pad="tan")
    t.rpair(4, 19.5, 7, 7.5, 23.5, 11.5, "brown", 0.6)         # уши
    t.pair(4.9, 20, 6.7, 6.7, 22.5, 7, "tan")
    muzzle(t, "tan_lt")
    t.pair(6.2, 8.3, 7.1, 9.6, 10.9, 7.7, "red")               # бант
    t.pair(7.5, 6.3, 7.2, 9.0, 8.5, 7.6, "red")
    t.box(9, 8.5, 6.9, 11, 10.7, 7.7, "red_dk")


@toy("toy_bunny", "Bunny", "Зайчик", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "bunny", "pink_lt", pad="pink_lt")
    t.pair(5.5, 21, 8, 8.5, 26, 11, "bunny")                   # длинные уши
    t.pair(4.6, 26, 8, 7.6, 31, 11, "bunny")
    t.pair(6.4, 21.5, 7.7, 7.6, 25.5, 8, "pink")
    t.pair(5.6, 26.5, 7.7, 6.8, 30, 8, "pink")
    t.box(8.6, 12.2, 3.7, 11.4, 14.3, 5.2, "bunny")            # мордочка
    t.box(9.2, 13.4, 3.4, 10.8, 14.8, 3.7, "pink")             # носик
    t.box(9.6, 12.6, 3.55, 10.4, 13.3, 3.7, "pink_dk")
    t.box(7, 3, 16, 13, 8, 18.5, "bunny")                      # хвостик
    t.pair(7.4, 8.4, 7.1, 9.6, 10.4, 7.7, "pink")              # бантик
    t.box(9, 8.6, 6.9, 11, 10.3, 7.7, "pink_dk")


@toy("toy_panda", "Panda", "Панда", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "black", "white", head="white", arm="black", foot="black", pad="black")
    t.box(6, 3.2, 7.6, 14, 10.4, 8, "white")                   # белое пузо/грудь
    t.rpair(3.5, 20, 6.5, 8, 24.5, 11, "black", 0.8)           # уши
    t.pair(5.6, 14.2, 4.4, 9.2, 18.4, 5.0, "black")            # пятна вокруг глаз
    t.pair(6.5, 15.4, 4.25, 7.7, 17.2, 4.4, "black")
    t.pair(6.9, 16.4, 4.1, 7.5, 17.0, 4.25, "hl")
    muzzle(t, "white", w=2.2, top=14.6)


@toy("toy_cat", "Kitten", "Котик", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "gray", "white", head="gray", pad="gray_lt")
    t.pair(4.5, 20, 7.5, 8.3, 23, 11.5, "gray")                # острые уши
    t.pair(4.9, 23, 8.2, 7.4, 25.2, 10.8, "gray_dk")
    t.pair(5.3, 20.4, 7.2, 7.2, 23.2, 7.5, "pink")
    t.box(8.6, 15.4, 4.6, 11.4, 19.4, 5.0, "white")            # белая полоска на мордочке
    t.box(8.4, 21, 6.5, 9.0, 21.5, 12, "gray_dk")              # полоски на лбу
    t.box(9.7, 21, 6.5, 10.3, 21.5, 12, "gray_dk")
    t.box(11, 21, 6.5, 11.6, 21.5, 12, "gray_dk")
    muzzle(t, "white", nose="pink", w=2.2, top=14.8)
    t.rbox(13, 3, 15, 15.5, 8, 17.5, "gray", 0.5)              # хвост-кочерга
    t.rbox(13.5, 7, 15.4, 16, 14, 17.6, "gray", 0.5)
    t.box(13.5, 13, 15.4, 16, 14.3, 17.6, "gray_dk")


@toy("toy_fox", "Fox", "Лисичка", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "orange", "white", foot="orange", pad="orange_lt")
    t.pair(4.5, 20, 7, 8.2, 23.2, 11, "orange")                # уши
    t.pair(4.8, 23.2, 7.6, 7.4, 25.6, 10.4, "orange_dk")
    t.pair(5.2, 20.3, 6.7, 7.2, 23.3, 7, "white")
    t.pair(4, 11, 4.4, 8.6, 14.4, 5.1, "white")                # белые щёчки
    muzzle(t, "white", w=2.4, top=14.4, out=3.4)
    t.rbox(7, 2, 16, 13, 11, 21, "orange", 0.8)                # пушистый хвост
    t.box(7.2, 2.2, 19.4, 12.8, 7, 21.2, "white")


@toy("toy_dino", "Dino", "Динозавр", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "green", "cream", arm="green", foot="green", pad="green_dk")
    t.rbox(5.2, 11, 2.2, 14.8, 17.4, 6, "green", 0.8)          # морда
    t.box(5.8, 11, 2.0, 14.2, 12.6, 4.4, "cream")              # светлая нижняя челюсть
    t.pair(7, 15.2, 1.8, 8.2, 16.4, 2.2, "green_dk")           # ноздри
    t.pair(5, 17, 4.5, 7, 19.6, 5, "white")                    # глаза
    t.pair(5.6, 17.4, 4.3, 6.6, 18.8, 4.5, "black")
    t.box(8.4, 21, 6, 11.6, 22.6, 12, "green_lt")              # бугорок на голове
    for y in (9.5, 6.5, 3.5):                                  # гребень на спине
        t.box(8.5, y, 16, 11.5, y + 2.2, 17.8, "green_lt")
    t.rbox(7.5, 2, 15.5, 12.5, 7, 20, "green", 0.8)            # хвост
    t.box(8.2, 2, 20, 11.8, 5, 24, "green")
    t.pair(5, 0, 4.2, 5.7, 0.9, 4.5, "white")                  # коготки
    t.pair(6.1, 0, 4.2, 6.8, 0.9, 4.5, "white")


@toy("toy_dog", "Puppy", "Собачка", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "dog", "dog_lt", head="dog_lt", pad="dog_lt")
    t.rpair(2.6, 10, 6, 5, 19.5, 11.5, "dog_ear", 0.7)         # висячие уши
    t.pair(3.4, 19.4, 6.4, 5.5, 20.4, 10.6, "dog_ear")
    muzzle(t, "dog_lt", w=2.6, top=14.6)
    t.box(9.1, 11.6, 3.6, 10.9, 12.5, 4.0, "pink")             # язычок
    t.box(7, 9.8, 7.0, 13, 11.2, 7.7, "red")                   # ошейник


@toy("toy_cow", "Cow", "Коровка", sx=1.3, sy=0.92, sz=1.05)
def _(t):
    rig(t, "white", "white", head="white", arm="cow", foot="cow", pad="white")
    t.box(5.5, 4, 7.4, 8.8, 10, 8, "cow")                      # пятна на теле
    t.box(5.5, 3, 16, 10, 9, 16.4, "cow")
    t.rpair(2.5, 16, 7, 5.5, 20.5, 11.5, "cow", 0.7)           # чёрные ушки
    t.pair(3.0, 17, 6.7, 4.6, 19, 7, "cow_pink")
    t.pair(5, 21, 8, 7, 22.2, 10, "cow_pink")                  # розовые бантики на макушке
    t.pair(4, 11.5, 4.5, 7.8, 18.5, 5.2, "cow")                # тёмные пятна на мордочке
    t.rbox(7, 11.2, 3.0, 13, 15.8, 5.5, "cow_pink", 0.6)       # большой розовый пятачок
    t.pair(8.1, 13, 2.8, 9, 14, 3.0, "cow_pink_dk")


# ---------------------------------------------------------------- вывод
def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


ITEM_DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, -1.5, 0], "scale": [1.7, 1.7, 1.7]},
    "ground": {"translation": [0, 2, 0], "scale": [0.9, 0.9, 0.9]},
    "fixed": {"rotation": [0, 180, 0], "scale": [1.4, 1.4, 1.4]},
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [0.9, 0.9, 0.9]},
    "thirdperson_lefthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [0.9, 0.9, 0.9]},
    "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [1, 2.5, 1], "scale": [1.0, 1.0, 1.0]},
    "firstperson_lefthand": {"rotation": [0, 225, 0], "translation": [1, 2.5, 1], "scale": [1.0, 1.0, 1.0]},
}


def merge_lang(lang_file, entries):
    p = f"{A}/lang/{lang_file}"
    with open(p, encoding="utf-8") as f:
        data = json.load(f)
    data.update(entries)
    write_json(p, data)


def main():
    write_palette()
    en, ru = {"itemGroup.schoollockers_toys": "Miniaturia: Toys"}, {"itemGroup.schoollockers_toys": "Miniaturia: Игрушки"}
    java = []
    for t in TOYS:
        write_json(f"{A}/models/block/{t.id}.json", t.model())
        write_json(f"{A}/models/item/{t.id}.json", {"parent": f"schoollockers:block/{t.id}", "display": ITEM_DISPLAY})
        write_json(f"{A}/blockstates/{t.id}.json", {"variants": {
            f"facing={d}": {"model": f"schoollockers:block/{t.id}", **({"y": y} if y else {})}
            for d, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270))}})
        write_json(f"{D}/loot_table/blocks/{t.id}.json", {
            "type": "minecraft:block",
            "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"schoollockers:{t.id}"}],
                       "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
        en[f"block.schoollockers.{t.id}"] = t.en
        ru[f"block.schoollockers.{t.id}"] = t.ru
        b = t.bounds()
        java.append(f'        new Toy("{t.id}", {", ".join(f"{v:.3f}" for v in b)}),')
    merge_lang("en_us.json", en)
    merge_lang("ru_ru.json", ru)
    with open(f"{JAVA}/ToyData.java", "w", encoding="utf-8") as f:
        f.write("package ru.miniaturia.schoollockers;\n\n"
                "/** Генерируется tools/gen_toys.py. Габариты — по модели (в 1/16 блока, лицом на север). */\n"
                "public final class ToyData {\n"
                "    public record Toy(String id, double x1, double y1, double z1, double x2, double y2, double z2) {}\n\n"
                "    public static final Toy[] TOYS = {\n" + "\n".join(java) + "\n    };\n\n"
                "    private ToyData() {}\n}\n")
    print(f"{len(TOYS)} toys, {len(PALETTE)} colors")


if __name__ == "__main__":
    main()
