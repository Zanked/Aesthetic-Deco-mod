"""Превью игрушек без запуска игры:  python3 tools/preview_toys.py OUT_DIR [cols]
Каждая игрушка рисуется отдельным кадром (общая сетка), чтобы было видно детали."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw
import preview_models as pm
import gen_toys

CELL_W, CELL_H = 260, 280

def main(out, cols=4, toys=None):
    os.makedirs(out, exist_ok=True)
    toys = toys or gen_toys.TOYS
    rows = (len(toys) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * CELL_W, rows * CELL_H), pm.Scene().bg if False else (26, 30, 44))
    d = ImageDraw.Draw(sheet)
    for i, t in enumerate(toys):
        s = pm.Scene(az=-30, pitch=22, scale=15, size=(CELL_W, CELL_H - 30), center=(8, 6.2, 8))
        s.add_model(f"schoollockers:block/{t.id}")
        r, c = divmod(i, cols)
        sheet.paste(s.image(), (c * CELL_W, r * CELL_H))
        d.text((c * CELL_W + 12, r * CELL_H + CELL_H - 24), t.id.replace("toy_", ""), fill=(190, 196, 215))
    sheet.save(f"{out}/toys_batch.png", optimize=True)

if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 4)
