"""Мини-рендерер блочных моделей Minecraft (без игры) для проверки ассетов мода.
Читает настоящие JSON-модели/блокстейты и PNG из src/main/resources и рисует превью.

    python3 tools/preview_models.py OUT_DIR
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = f"{ROOT}/src/main/resources/assets/schoollockers"
_tex_cache, _model_cache = {}, {}

SHADE = {"up": 1.0, "down": 0.5, "north": 0.8, "south": 0.8, "east": 0.6, "west": 0.6}
NORMAL = {"up": (0, 1, 0), "down": (0, -1, 0), "north": (0, 0, -1), "south": (0, 0, 1), "east": (1, 0, 0),
          "west": (-1, 0, 0)}
ROT_DIR = {"north": "east", "east": "south", "south": "west", "west": "north"}


def load_tex(ref):
    ns, path = ref.split(":")
    if path not in _tex_cache:
        _tex_cache[path] = np.asarray(Image.open(f"{A}/textures/{path}.png").convert("RGBA"))
    return _tex_cache[path]


def load_model(ref):
    """Возвращает (elements, textures) с учётом parent."""
    if ref in _model_cache:
        return _model_cache[ref]
    ns, path = ref.split(":")
    with open(f"{A}/models/{path}.json", encoding="utf-8") as f:
        m = json.load(f)
    els, texs = m.get("elements"), dict(m.get("textures", {}))
    if "parent" in m and not m["parent"].startswith("minecraft:"):
        pe, pt = load_model(m["parent"])
        els = els if els is not None else pe
        texs = {**pt, **texs}
    _model_cache[ref] = (els or [], texs)
    return _model_cache[ref]


def resolve(texs, name):
    while name.startswith("#"):
        name = texs[name[1:]]
    return name


def face_corners(e, d):
    (x1, y1, z1), (x2, y2, z2) = e["from"], e["to"]
    P = lambda *v: np.array(v, dtype=np.float64)
    return {
        "north": (P(x2, y2, z1), P(x1, y2, z1), P(x2, y1, z1)),
        "south": (P(x1, y2, z2), P(x2, y2, z2), P(x1, y1, z2)),
        "west": (P(x1, y2, z1), P(x1, y2, z2), P(x1, y1, z1)),
        "east": (P(x2, y2, z2), P(x2, y2, z1), P(x2, y1, z2)),
        "up": (P(x1, y2, z1), P(x2, y2, z1), P(x1, y2, z2)),
        "down": (P(x1, y1, z2), P(x2, y1, z2), P(x1, y1, z1)),
    }[d]


def rot_y(p, deg):
    for _ in range((deg // 90) % 4):
        p = np.array([16 - p[2], p[1], p[0]])
    return p


def rot_dir(d, deg):
    for _ in range((deg // 90) % 4):
        d = ROT_DIR.get(d, d)
    return d


class Scene:
    def __init__(self, az=-35, pitch=28, scale=14, size=(900, 700), center=(0, 16, 0), bg=(26, 30, 44)):
        self.W, self.H = size[0] * 2, size[1] * 2
        self.scale = scale * 2
        self.center = np.array(center, dtype=np.float64)
        a, p = math.radians(az), math.radians(pitch)
        c = np.array([math.sin(a) * math.cos(p), math.sin(p), -math.cos(a) * math.cos(p)])
        self.f = -c
        up = np.array([0, 1, 0.0])
        self.r = np.cross(self.f, up)
        self.r /= np.linalg.norm(self.r)
        self.u = np.cross(self.r, self.f)
        self.z = np.full(self.W * self.H, np.inf)
        self.col = np.zeros((self.W * self.H, 4), dtype=np.float32)
        self.bg = bg

    def project(self, P):
        q = P - self.center
        x = q @ self.r
        y = q @ self.u
        z = q @ self.f
        return self.W / 2 + x * self.scale, self.H / 2 - y * self.scale, z

    def add_model(self, ref, off=(0, 0, 0), roty=0, texs_override=None):
        els, texs = load_model(ref)
        if texs_override:
            texs = {**texs, **texs_override}
        for e in els:
            for d, fc in e["faces"].items():
                nd = rot_dir(d, roty)
                n = np.array(NORMAL[nd], dtype=np.float64)
                if n @ self.f > 0:           # задняя грань
                    continue
                tl, tr, bl = face_corners(e, d)
                tl, tr, bl = [rot_y(p, roty) + np.array(off) for p in (tl, tr, bl)]
                tex = load_tex(resolve(texs, fc["texture"]))
                th, tw = tex.shape[:2]
                u1, v1, u2, v2 = fc["uv"]
                lu = np.linalg.norm(tr - tl) * self.scale
                lv = np.linalg.norm(bl - tl) * self.scale
                nu, nv = max(2, int(lu * 1.8)), max(2, int(lv * 1.8))
                uu = (np.arange(nu) + 0.5) / nu
                vv = (np.arange(nv) + 0.5) / nv
                UU, VV = np.meshgrid(uu, vv)
                P = tl[None, None] + (tr - tl)[None, None] * UU[..., None] + (bl - tl)[None, None] * VV[..., None]
                sx, sy, sz = self.project(P.reshape(-1, 3))
                tu = (u1 + (u2 - u1) * UU).reshape(-1) / 16 * tw
                tv = (v1 + (v2 - v1) * VV).reshape(-1) / 16 * th
                ix = np.clip(tu.astype(int), 0, tw - 1)
                iy = np.clip(tv.astype(int), 0, th - 1)
                px = tex[iy, ix].astype(np.float32)
                ok = px[:, 3] > 128
                X, Y = sx.astype(int), sy.astype(int)
                ok &= (X >= 0) & (X < self.W) & (Y >= 0) & (Y < self.H)
                idx = (Y * self.W + X)[ok]
                zz = sz[ok]
                c = px[ok]
                c[:, :3] *= SHADE[nd]
                m = zz < self.z[idx]
                self.z[idx[m]] = zz[m]
                self.col[idx[m]] = c[m]

    def image(self):
        a = self.col.reshape(self.H, self.W, 4)
        covered = np.isfinite(self.z).reshape(self.H, self.W)
        out = np.zeros((self.H, self.W, 3), dtype=np.float32)
        out[:] = self.bg
        out[covered] = a[covered][:, :3]
        im = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), "RGB")
        return im.resize((self.W // 2, self.H // 2), Image.LANCZOS)


def state_models(color, single, facing, half, open_left=False, open_right=False, right=False):
    """Какие модели блокстейт применит для состояния."""
    name = f"locker_single_{color}" if single else f"locker_{color}"
    with open(f"{A}/blockstates/{name}.json", encoding="utf-8") as f:
        bs = json.load(f)
    st = {"facing": facing, "half": half, "open_left": str(open_left).lower(),
          "open_right": str(open_right).lower(), "right": str(right).lower()}
    out = []
    for part in bs["multipart"]:
        if all(st.get(k) == v for k, v in part["when"].items()):
            out.append((part["apply"]["model"], part["apply"].get("y", 0)))
    return out


def add_block(scene, pos, color, single=False, facing="north", right=False, open_left=False, open_right=False):
    ox, oy, oz = pos
    for half, dy in (("lower", 0), ("upper", 16)):
        for model, y in state_models(color, single, facing, half, open_left, open_right, right):
            scene.add_model(model, (ox * 16, (oy * 32) + dy, oz * 16), y)


def main(out):
    os.makedirs(out, exist_ok=True)
    colors = ['white', 'light_gray', 'gray', 'dark_gray', 'black', 'blue', 'light_blue', 'green', 'yellow', 'orange',
              'red', 'pink', 'purple', 'teal', 'brown', 'pastel_pink', 'pastel_blue', 'pastel_green']

    # 1. два ряда: двойные и одинарные шкафчики всех цветов (как на референсе)
    for name, single in (("doubles", False), ("singles", True)):
        s = Scene(az=-24, pitch=16, scale=4.1, size=(1800, 640), center=(len(colors) * 8, 24, 8))
        for i, c in enumerate(colors):
            add_block(s, (len(colors) - 1 - i, 0, 0), c, single=single, right=(i % 2 == 0))
        s.image().save(f"{out}/all_{name}.png")

    # 2. одинарные + двойные, часть открыта
    s = Scene(az=-28, pitch=20, scale=8, size=(1400, 760), center=(4 * 16, 16, 8))
    seq = [("teal", True, dict(right=True, open_right=True)), ("purple", False, dict(open_right=True)),
           ("yellow", False, dict(open_left=True)), ("green", False, {}),
           ("red", True, dict(right=False, open_left=True)), ("red", True, dict(right=True)),
           ("blue", True, dict(right=False)), ("blue", True, dict(right=True))]
    for i, (c, single, kw) in enumerate(seq):
        add_block(s, (len(seq) - 1 - i, 0, 0), c, single=single, **kw)
    s.image().save(f"{out}/open_and_singles.png")

    # 3. разные повороты и вид сзади/сбоку
    s = Scene(az=40, pitch=26, scale=8, size=(1100, 700), center=(1.5 * 16, 16, 24))
    add_block(s, (0, 0, 0), "white", facing="north")
    add_block(s, (1, 0, 0), "orange", facing="north", single=True, right=False)
    add_block(s, (3, 0, 1), "pink", facing="west")
    add_block(s, (3, 0, 3), "brown", facing="south", single=True, right=True)
    add_block(s, (0, 0, 3), "black", facing="east", open_left=True)
    s.image().save(f"{out}/angles.png")

    # 4. крупно: открытая дверь и закрытая
    s = Scene(az=-18, pitch=14, scale=26, size=(1000, 800), center=(8, 14, 6))
    add_block(s, (0, 0, 0), "blue", open_right=True)
    s.image().save(f"{out}/close_open.png")

    # 5. иконки предметов (приближённо к GUI: вид с северо-востока)
    s = Scene(az=45, pitch=30, scale=7.5, size=(560, 330), center=(24, 16, 8), bg=(70, 74, 92))
    for i, (c, single) in enumerate((("blue", False), ("red", True), ("yellow", False), ("pink", True))):
        s.add_model(f"schoollockers:item/locker_{'single_' if single else ''}{c}", (-(i * 20) + 40, 0, 0), 0)
    s.image().save(f"{out}/items.png")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "preview")
