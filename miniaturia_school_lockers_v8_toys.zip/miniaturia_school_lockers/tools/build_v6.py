"""v6: шкафчики высотой ровно 2 блока (16+16), двойные и ОДИНАРНЫЕ.

Генерирует: модели, блокстейты, предметные модели, рецепты, лут, lang, тег pickaxe.
Текстуры рисует tools/gen_textures.py, ключ — tools/gen_key.py.

Запуск:  python3 tools/build_v6.py
"""
import glob
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/schoollockers"
D = f"{RES}/data/schoollockers"
MOD = f"{A}/models/block"

COLORS = ['white', 'light_gray', 'gray', 'dark_gray', 'black', 'blue', 'light_blue', 'green', 'yellow', 'orange',
          'red', 'pink', 'purple', 'teal', 'brown', 'pastel_pink', 'pastel_blue', 'pastel_green']
EN = {'white': 'White', 'light_gray': 'Light Gray', 'gray': 'Gray', 'dark_gray': 'Dark Gray', 'black': 'Black',
      'blue': 'Blue', 'light_blue': 'Light Blue', 'green': 'Green', 'yellow': 'Yellow', 'orange': 'Orange',
      'red': 'Red', 'pink': 'Pink', 'purple': 'Purple', 'teal': 'Teal', 'brown': 'Brown',
      'pastel_pink': 'Pastel Pink', 'pastel_blue': 'Pastel Blue', 'pastel_green': 'Pastel Green'}
RU = {'white': 'белый', 'light_gray': 'светло-серый', 'gray': 'серый', 'dark_gray': 'тёмно-серый', 'black': 'чёрный',
      'blue': 'синий', 'light_blue': 'голубой', 'green': 'зелёный', 'yellow': 'жёлтый', 'orange': 'оранжевый',
      'red': 'красный', 'pink': 'розовый', 'purple': 'фиолетовый', 'teal': 'бирюзовый', 'brown': 'коричневый',
      'pastel_pink': 'пастельно-розовый', 'pastel_blue': 'пастельно-голубой', 'pastel_green': 'пастельно-зелёный'}
DYE = {'white': ('white_dye', None), 'light_gray': ('light_gray_dye', None), 'gray': ('gray_dye', None),
       'dark_gray': ('gray_dye', 'black_dye'), 'black': ('black_dye', None), 'blue': ('blue_dye', None),
       'light_blue': ('light_blue_dye', None), 'green': ('green_dye', None), 'yellow': ('yellow_dye', None),
       'orange': ('orange_dye', None), 'red': ('red_dye', None), 'pink': ('pink_dye', None),
       'purple': ('purple_dye', None), 'teal': ('cyan_dye', None), 'brown': ('brown_dye', None),
       'pastel_pink': ('pink_dye', 'white_dye'), 'pastel_blue': ('light_blue_dye', 'white_dye'),
       'pastel_green': ('lime_dye', 'white_dye')}

H = 16                     # высота одного блока; шкафчик = 2 блока = 32 ед. (дверь 8x32)
DOORS = {"left": (8, 16), "right": (0, 8)}     # диапазон x двери (вид спереди, лицо на север)


def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def F(uv, tex):
    return {"uv": uv, "texture": tex}


def box(a, b, faces):
    return {"from": a, "to": b, "faces": faces}


# Атлас половины: лицо u 0..8, бок u 8..16. Крыша 128x128 целиком = uv 0..16 на 8 ед. (т.е. ед. -> *2).
FRONT = [0, 0, 8, H]
SIDE = [8, 0, 16, H]


def handle_box(x1, x2, z1, z2, faces):
    return box([x1, 13.5, z1], [x2, 15.5, z2], {k: F([0, 0, 16, 16], "#handle") for k in faces})


def closed(side, top, dy=0, t="#t", handle=True):
    """Закрытая дверь 8x16 (одна половина шкафчика). Ручка: у видимого левого края, только в нижнем блоке."""
    a, b = DOORS[side]
    faces = {"north": F(FRONT, t), "south": F(SIDE, t), "east": F(SIDE, t), "west": F(SIDE, t)}
    if top:
        faces["up"] = F([0, 0, 16, 16], "#roof")
    els = [box([a, dy, 6], [b, dy + H, 14], faces)]
    if handle and not top:
        els.append(handle_box(b - 3.5, b - 1.5, 5, 6, ("north", "east", "west", "up", "down")))
    return els


def opened(side, top, t="#t"):
    """Открытая дверь: нужны задняя/боковые стенки, пол (низ) или потолок (верх) и распахнутая створка.
    Петля у правого (для смотрящего) края, ручка — у левого."""
    a, b = DOORS[side]
    els = []
    # задняя стенка
    back = {"north": F([0, 0, 8, H], "#inside"), "south": F(SIDE, t)}
    if top:
        back["up"] = F([0, 14, 16, 16], "#roof")
    els.append(box([a, 0, 13], [b, H, 14], back))
    # боковая стенка у ручки (смотрящему слева): x b-1..b
    lw = {"north": F([8, 0, 9, H], t), "east": F([8, 0, 15, H], t), "west": F([0, 0, 7, H], "#inside")}
    if top:
        lw["up"] = F([14, 0, 16, 14], "#roof")
    els.append(box([b - 1, 0, 6], [b, H, 13], lw))
    # боковая стенка у петли: x a..a+1
    rw = {"north": F([8, 0, 9, H], t), "west": F([8, 0, 15, H], t), "east": F([0, 0, 7, H], "#inside")}
    if top:
        rw["up"] = F([0, 0, 2, 14], "#roof")
    els.append(box([a, 0, 6], [a + 1, H, 13], rw))
    # пол / потолок
    if not top:
        els.append(box([a + 1, 0, 6], [b - 1, 1, 13],
                       {"up": F([0, 0, 6, 7], "#inside"), "north": F([9, 15, 15, 16], t)}))
    else:
        els.append(box([a + 1, H - 1, 6], [b - 1, H, 13],
                       {"down": F([0, 0, 6, 7], "#inside"), "up": F([2, 0, 14, 14], "#roof"),
                        "north": F([9, 0, 15, 1], t)}))
    # распахнутая створка у петли (x a..a+1, наружу на 8 ед.)
    pf = {"west": F(FRONT, t), "east": F([0, 0, 8, H], "#inside"), "north": F([8, 0, 9, H], t)}
    if top:
        pf["up"] = F([0, 0, 2, 16], "#roof")
    els.append(box([a, 0, -2], [a + 1, H, 6], pf))
    if not top:
        els.append(handle_box(a - 1, a, -0.5, 1.5, ("west", "north", "south", "up", "down")))
    return els


# ---------- шаблоны моделей дверей (без цвета) ----------
for f in glob.glob(f"{MOD}/*.json"):
    os.remove(f)
for side in DOORS:
    for half, top in (("bottom", False), ("top", True)):
        wj(f"{MOD}/locker_door_{side}_{half}_closed.json", {"elements": closed(side, top)})
        wj(f"{MOD}/locker_door_{side}_{half}_open.json", {"elements": opened(side, top)})

ROT = {"north": 0, "east": 90, "south": 180, "west": 270}
ITEM_DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, -3.1, 0], "scale": [0.41, 0.41, 0.41]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.26, 0.26, 0.26]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, -3.3, 0], "scale": [0.37, 0.37, 0.37]},
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 0, 0], "scale": [0.30, 0.30, 0.30]},
    "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, -2.6, 0], "scale": [0.34, 0.34, 0.34]},
}


def shifted(els, dx):
    out = []
    for e in els:
        e = json.loads(json.dumps(e))
        e["from"][0] += dx
        e["to"][0] += dx
        out.append(e)
    return out


def item_elements(sides, dx=0):
    els = []
    for side in sides:
        els += closed(side, False, 0, "#tb")
        els += closed(side, True, H, "#tt", handle=False)
    return shifted(els, dx) if dx else els


for c in COLORS:
    T = lambda n: f"schoollockers:block/locker_{c}_{n}"
    for side in DOORS:
        for half in ("bottom", "top"):
            for st in ("closed", "open"):
                wj(f"{MOD}/locker_{c}_door_{side}_{half}_{st}.json", {
                    "parent": f"schoollockers:block/locker_door_{side}_{half}_{st}",
                    "textures": {"t": T(half), "roof": T("roof"), "inside": "schoollockers:block/locker_inside",
                                 "handle": "schoollockers:block/locker_handle", "particle": T(half)}})

    def parts(single):
        out = []
        for facing, y in ROT.items():
            for half, hn in (("lower", "bottom"), ("upper", "top")):
                for side, prop in (("left", "open_left"), ("right", "open_right")):
                    for st, val in (("closed", "false"), ("open", "true")):
                        ap = {"model": f"schoollockers:block/locker_{c}_door_{side}_{hn}_{st}"}
                        if y:
                            ap["y"] = y
                        when = {"facing": facing, "half": half, prop: val}
                        if single:
                            when["right"] = "true" if side == "right" else "false"
                        out.append({"when": when, "apply": ap})
        return out

    wj(f"{A}/blockstates/locker_{c}.json", {"multipart": parts(False)})
    wj(f"{A}/blockstates/locker_single_{c}.json", {"multipart": parts(True)})

    tex = {"tb": T("bottom"), "tt": T("top"), "roof": T("roof"), "handle": "schoollockers:block/locker_handle",
           "particle": T("bottom")}
    wj(f"{A}/models/item/locker_{c}.json", {"textures": tex, "elements": item_elements(("left", "right")),
                                            "display": ITEM_DISPLAY})
    wj(f"{A}/models/item/locker_single_{c}.json", {"textures": tex, "elements": item_elements(("left",), -4),
                                                   "display": ITEM_DISPLAY})

# ---------- рецепты и лут ----------
for f in glob.glob(f"{D}/recipe/locker_*.json"):
    if not f.endswith("locker_key.json"):
        os.remove(f)
for f in glob.glob(f"{D}/loot_table/blocks/*.json"):
    os.remove(f)

ing = lambda i: {"item": f"minecraft:{i}"}
for c in COLORS:
    d1, d2 = DYE[c]
    key = {"I": ing("iron_ingot"), "D": ing(d1)}
    if d2:
        key["E"] = ing(d2)
        pattern = ["II", "ID", "IE"]
    else:
        pattern = ["II", "ID", "II"]
    wj(f"{D}/recipe/locker_{c}.json", {"type": "minecraft:crafting_shaped", "category": "building", "key": key,
                                       "pattern": pattern, "result": {"id": f"schoollockers:locker_{c}", "count": 2}})
    # одинарный: 3 слитка + краситель(и)
    skey = {"I": ing("iron_ingot"), "D": ing(d1)}
    if d2:
        skey["E"] = ing(d2)
        spattern = ["II", "DE"]
    else:
        spattern = ["II", "ID"]
    wj(f"{D}/recipe/locker_single_{c}.json", {"type": "minecraft:crafting_shaped", "category": "building",
                                              "key": skey, "pattern": spattern,
                                              "result": {"id": f"schoollockers:locker_single_{c}", "count": 1}})
    # обмен: 1 двойной -> 2 одинарных, 2 одинарных -> 1 двойной
    wj(f"{D}/recipe/locker_single_{c}_from_double.json", {
        "type": "minecraft:crafting_shapeless", "category": "building",
        "ingredients": [{"item": f"schoollockers:locker_{c}"}],
        "result": {"id": f"schoollockers:locker_single_{c}", "count": 2}})
    wj(f"{D}/recipe/locker_{c}_from_singles.json", {
        "type": "minecraft:crafting_shapeless", "category": "building",
        "ingredients": [{"item": f"schoollockers:locker_single_{c}"}] * 2,
        "result": {"id": f"schoollockers:locker_{c}", "count": 1}})
    for name in (f"locker_{c}", f"locker_single_{c}"):
        wj(f"{D}/loot_table/blocks/{name}.json", {
            "type": "minecraft:block",
            "pools": [{"rolls": 1,
                       "entries": [{"type": "minecraft:item", "name": f"schoollockers:{name}"}],
                       "conditions": [
                           {"condition": "minecraft:block_state_property", "block": f"schoollockers:{name}",
                            "properties": {"half": "lower"}},
                           {"condition": "minecraft:survives_explosion"}]}]})

# ---------- тег pickaxe ----------
wj(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", {
    "values": [f"schoollockers:locker_{c}" for c in COLORS] + [f"schoollockers:locker_single_{c}" for c in COLORS]})

# ---------- lang ----------
common_ru = {
    "itemGroup.schoollockers": "Miniaturia: Школьные шкафчики",
    "container.schoollockers.locker": "Школьный шкафчик",
    "item.schoollockers.locker_key": "Ключ от шкафчика",
    "message.schoollockers.locked": "Шкафчик заперт",
    "message.schoollockers.lock_on": "Шкафчик заперт на ключ",
    "message.schoollockers.lock_off": "Шкафчик отперт",
    "message.schoollockers.wrong_key": "Этот ключ не подходит",
    "tooltip.schoollockers.key_bound": "Ключ №%s",
    "tooltip.schoollockers.key_blank": "Пустой: привяжется при первом запирании",
    "tooltip.schoollockers.key_hint": "ПКМ по дверце — запереть/отпереть"}
common_en = {
    "itemGroup.schoollockers": "Miniaturia: School Lockers",
    "container.schoollockers.locker": "School Locker",
    "item.schoollockers.locker_key": "Locker Key",
    "message.schoollockers.locked": "The locker is locked",
    "message.schoollockers.lock_on": "Locker locked",
    "message.schoollockers.lock_off": "Locker unlocked",
    "message.schoollockers.wrong_key": "This key doesn't fit",
    "tooltip.schoollockers.key_bound": "Key #%s",
    "tooltip.schoollockers.key_blank": "Blank: binds on first lock",
    "tooltip.schoollockers.key_hint": "Right-click a door to lock/unlock"}
ru, en = {}, {}
for c in COLORS:
    ru[f"block.schoollockers.locker_{c}"] = f"Школьный шкафчик двойной ({RU[c]})"
    en[f"block.schoollockers.locker_{c}"] = f"Double School Locker ({EN[c]})"
for c in COLORS:
    ru[f"block.schoollockers.locker_single_{c}"] = f"Школьный шкафчик одинарный ({RU[c]})"
    en[f"block.schoollockers.locker_single_{c}"] = f"Single School Locker ({EN[c]})"
ru.update(common_ru)
en.update(common_en)
wj(f"{A}/lang/ru_ru.json", ru)
wj(f"{A}/lang/en_us.json", en)

# ---------- рецепт ключа ----------
wj(f"{D}/recipe/locker_key.json", {
    "type": "minecraft:crafting_shapeless", "category": "misc",
    "ingredients": [ing("iron_ingot"), ing("iron_nugget")],
    "result": {"id": "schoollockers:locker_key", "count": 1}})
wj(f"{A}/models/item/locker_key.json",
   {"parent": "minecraft:item/generated", "textures": {"layer0": "schoollockers:item/locker_key"}})
print("ok")
