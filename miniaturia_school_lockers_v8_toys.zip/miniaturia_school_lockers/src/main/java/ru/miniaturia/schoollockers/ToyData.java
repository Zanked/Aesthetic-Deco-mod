package ru.miniaturia.schoollockers;

/** Генерируется tools/gen_toys.py. Габариты — по модели (в 1/16 блока, лицом на север). */
public final class ToyData {
    public record Toy(String id, double x1, double y1, double z1, double x2, double y2, double z2) {}

    public static final Toy[] TOYS = {
        new Toy("toy_bear", 3.450, 0.000, 4.588, 12.550, 10.810, 11.150),
        new Toy("toy_bunny", 3.450, 0.000, 4.535, 12.550, 14.260, 12.463),
        new Toy("toy_panda", 3.450, 0.000, 4.588, 12.550, 11.270, 11.150),
        new Toy("toy_cat", 3.450, 0.000, 4.588, 12.550, 11.592, 11.990),
        new Toy("toy_fox", 3.450, 0.000, 4.377, 12.550, 11.776, 13.880),
        new Toy("toy_dino", 3.450, 0.000, 3.695, 12.550, 10.396, 15.350),
        new Toy("toy_dog", 3.190, 0.000, 4.588, 12.810, 9.430, 11.150),
        new Toy("toy_cow", 3.125, 0.000, 4.220, 12.875, 10.212, 11.360),
    };

    private ToyData() {}
}
