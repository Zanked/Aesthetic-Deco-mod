package ru.miniaturia.schoollockers;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(SchoolLockers.MODID)
public class SchoolLockers {
    public static final String MODID = "schoollockers";
    public static final String[] COLORS = { "white", "light_gray", "gray", "dark_gray", "black", "blue", "light_blue", "green", "yellow", "orange", "red", "pink", "purple", "teal", "brown", "pastel_pink", "pastel_blue", "pastel_green" };

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);

    public static final List<DeferredItem<Item>> LOCKER_ITEMS = new ArrayList<>();
    public static final List<DeferredBlock<LockerBlock>> LOCKER_BLOCKS = new ArrayList<>();
    /** Одинарные шкафчики (одна дверь). */
    public static final List<DeferredItem<Item>> SINGLE_ITEMS = new ArrayList<>();
    public static final List<DeferredBlock<SingleLockerBlock>> SINGLE_BLOCKS = new ArrayList<>();

    /** Игрушки (генерируются tools/gen_toys.py -> ToyData). */
    public static final List<DeferredItem<Item>> TOY_ITEMS = new ArrayList<>();

    static {
        for (ToyData.Toy toy : ToyData.TOYS) {
            DeferredBlock<ToyBlock> block = BLOCKS.register(toy.id(), () -> new ToyBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.WOOL)
                            .strength(0.4F)
                            .sound(SoundType.WOOL)
                            .noOcclusion(), toy));
            TOY_ITEMS.add(ITEMS.register(toy.id(), () -> new BlockItem(block.get(), new Item.Properties())));
        }

        for (String color : COLORS) {
            String name = "locker_" + color;
            DeferredBlock<LockerBlock> block = BLOCKS.register(name, () -> new LockerBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.METAL)
                            .requiresCorrectToolForDrops()
                            .noOcclusion()));
            LOCKER_BLOCKS.add(block);
            LOCKER_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));

            String singleName = "locker_single_" + color;
            DeferredBlock<SingleLockerBlock> single = BLOCKS.register(singleName, () -> new SingleLockerBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.METAL)
                            .requiresCorrectToolForDrops()
                            .noOcclusion()));
            SINGLE_BLOCKS.add(single);
            SINGLE_ITEMS.add(ITEMS.register(singleName, () -> new BlockItem(single.get(), new Item.Properties())));
        }
    }

    private static Block[] allLockerBlocks() {
        return java.util.stream.Stream.concat(
                LOCKER_BLOCKS.stream().map(DeferredBlock::get),
                SINGLE_BLOCKS.stream().map(DeferredBlock::get)).toArray(Block[]::new);
    }

    public static final DeferredItem<Item> KEY = ITEMS.register("locker_key",
            () -> new LockerKeyItem(new Item.Properties().stacksTo(16)));

    public static final net.neoforged.neoforge.registries.DeferredHolder<BlockEntityType<?>, BlockEntityType<LockerBlockEntity>> LOCKER_BE =
            BLOCK_ENTITIES.register("locker", () -> BlockEntityType.Builder.of(
                    LockerBlockEntity::new,
                    allLockerBlocks()).build(null));

    public static final net.neoforged.neoforge.registries.DeferredHolder<CreativeModeTab, CreativeModeTab> TAB =
            TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> LOCKER_ITEMS.get(5).get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        LOCKER_ITEMS.forEach(i -> output.accept(i.get()));
                        SINGLE_ITEMS.forEach(i -> output.accept(i.get()));
                        output.accept(KEY.get());
                    })
                    .build());

    public static final net.neoforged.neoforge.registries.DeferredHolder<CreativeModeTab, CreativeModeTab> TOYS_TAB =
            TABS.register("toys", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID + "_toys"))
                    .icon(() -> TOY_ITEMS.get(0).get().getDefaultInstance())
                    .displayItems((params, output) -> TOY_ITEMS.forEach(i -> output.accept(i.get())))
                    .build());

    public SchoolLockers(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        TABS.register(modBus);
    }
}
