package ru.miniaturia.schoollockers;

import java.util.List;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;

/**
 * Ключ от шкафчика. Номер замка хранится в CUSTOM_DATA ("LockId").
 * Пустой ключ (без номера) привязывается к первому запертому им шкафчику;
 * один ключ может запирать сколько угодно дверец.
 */
public class LockerKeyItem extends Item {
    private static final String TAG = "LockId";

    public LockerKeyItem(Properties properties) {
        super(properties);
    }

    public static long getKeyId(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data == null ? 0L : data.copyTag().getLong(TAG);
    }

    public static void setKeyId(ItemStack stack, long id) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putLong(TAG, id));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        long id = getKeyId(stack);
        if (id == 0L) {
            tooltip.add(Component.translatable("tooltip.schoollockers.key_blank"));
        } else {
            tooltip.add(Component.translatable("tooltip.schoollockers.key_bound", String.format("%05X", id & 0xFFFFFL)));
        }
        tooltip.add(Component.translatable("tooltip.schoollockers.key_hint"));
    }
}
