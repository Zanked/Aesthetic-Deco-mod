package ru.miniaturia.schoollockers;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Игрушка-фигурка: декоративный блок с моделью из кубоидов. Смотрит на игрока при установке.
 * Габарит берётся из модели (ToyData, генерируется tools/gen_toys.py).
 */
public class ToyBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<ToyBlock> CODEC = simpleCodec(p -> new ToyBlock(p, null));

    private final VoxelShape[] shapes = new VoxelShape[4];

    public ToyBlock(Properties properties, @Nullable ToyData.Toy def) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
        for (Direction d : Direction.Plane.HORIZONTAL) {
            shapes[d.get2DDataValue()] = def == null
                    ? Block.box(4, 0, 4, 12, 12, 12)
                    : rotatedBox(d, def.x1(), def.y1(), def.z1(), def.x2(), def.y2(), def.z2());
        }
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }

    /** Бокс, заданный для лица на север, повёрнутый по часовой стрелке под нужное направление. */
    private static VoxelShape rotatedBox(Direction facing, double x1, double y1, double z1, double x2, double y2, double z2) {
        int turns = switch (facing) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
        double ax = x1, az = z1, bx = x2, bz = z2;
        for (int i = 0; i < turns; i++) {
            double nax = 16 - az, naz = ax, nbx = 16 - bz, nbz = bx;
            ax = nax;
            az = naz;
            bx = nbx;
            bz = nbz;
        }
        return Block.box(Math.min(ax, bx), y1, Math.min(az, bz), Math.max(ax, bx), y2, Math.max(az, bz));
    }
}
