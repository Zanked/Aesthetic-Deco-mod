package ru.miniaturia.schoollockers;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(SchoolLockers.MODID)
public class SchoolLockers {
    public static final String MODID = "schoollockers";
    public static final String[] COLORS = { "white", "light_gray", "gray", "dark_gray", "black", "blue", "light_blue", "green", "yellow", "orange", "red", "pink", "purple", "teal", "brown", "pastel_pink", "pastel_blue", "pastel_green" };

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);

    public static final List<DeferredItem<Item>> LOCKER_ITEMS = new ArrayList<>();
    public static final List<DeferredBlock<LockerBlock>> LOCKER_BLOCKS = new ArrayList<>();

    static {
        for (String color : COLORS) {
            String name = "locker_" + color;
            DeferredBlock<LockerBlock> block = BLOCKS.register(name, () -> new LockerBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.METAL)
                            .requiresCorrectToolForDrops()
                            .noOcclusion()));
            LOCKER_BLOCKS.add(block);
            LOCKER_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    public static final net.neoforged.neoforge.registries.DeferredHolder<BlockEntityType<?>, BlockEntityType<LockerBlockEntity>> LOCKER_BE =
            BLOCK_ENTITIES.register("locker", () -> BlockEntityType.Builder.of(
                    LockerBlockEntity::new,
                    LOCKER_BLOCKS.stream().map(DeferredBlock::get).toArray(Block[]::new)).build(null));

    public static final net.neoforged.neoforge.registries.DeferredHolder<CreativeModeTab, CreativeModeTab> TAB =
            TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> LOCKER_ITEMS.get(5).get().getDefaultInstance())
                    .displayItems((params, output) -> LOCKER_ITEMS.forEach(i -> output.accept(i.get())))
                    .build());

    public SchoolLockers(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        TABS.register(modBus);
    }
}
