# Miniaturia School Lockers (NeoForge 1.21.1)

Декоративные двухблочные школьные шкафчики, 18 цветов (вентиляция, ручка с замком, наклейки и записки).
Рецепт: 6 железных слитков + краситель = 2 шкафчика (тёмно-серый и пастельные — два красителя, см. recipe/*.json).

## Сборка .jar
Нужны JDK 21 и интернет.
1. Выполните `gradle wrapper --gradle-version 8.10.2` (или скопируйте gradlew, gradlew.bat и gradle/wrapper/gradle-wrapper.jar из официального NeoForge MDK 1.21.1).
2. `./gradlew build` (Windows: `gradlew.bat build`)
3. Готовый мод: `build/libs/miniaturia_school_lockers-1.0.0.jar` — положить в папку mods.

Тест в игре: `./gradlew runClient`.
Если Gradle не находит версию NeoForge — поменяйте `version` в build.gradle на любую 21.1.x с https://projects.neoforged.net/neoforged/neoforge

## Текстуры и модели
Текстуры вырезаны прямо из референс-картинки (tools/reference.png): передняя, боковая грани и крыша каждого из 18 шкафчиков, перспектива выпрямлена скриптом tools/extract_textures.py (нужен Pillow и numpy).
Модель: корпус 10x32x8 (две половины по 16 высоты), узкий и высокий, как на картинке. Ручка, замок, вентиляция, наклейки и записки нарисованы в текстуре.
Файлы в src/main/resources/assets/schoollockers/textures/block (32x32, на цвет: front_top, front_bottom, side_top, side_bottom, roof) можно доработать вручную.
